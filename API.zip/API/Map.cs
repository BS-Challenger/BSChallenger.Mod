﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSChallengeRanking.API
{
	internal class Map
	{
		internal string beatsaverID;
		internal string hash;
		internal string characteristic;
		internal string difficulty;
	}
}
