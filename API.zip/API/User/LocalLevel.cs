﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSChallengeRanking.API.User
{
	internal class LocalLevel
	{
		internal int passedMaps;
	}
}
